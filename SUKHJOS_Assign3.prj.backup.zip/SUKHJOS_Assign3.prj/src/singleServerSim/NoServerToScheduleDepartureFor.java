/**
 * Name: Joshua Sukhdeo
 * Student ID: 002217503
 */
package singleServerSim;

/**
 * @author joshs
 *
 */
public class NoServerToScheduleDepartureFor extends Exception {

	private static final long serialVersionUID = 1L;

}
